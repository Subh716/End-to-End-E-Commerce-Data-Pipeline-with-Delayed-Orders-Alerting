
# E-Commerce Order Pipeline 🚀  
End-to-End Data Engineering Project using Snowflake, dbt, and Airflow

## 🔧 Tools Used
- **Snowflake**: Cloud data warehouse
- **dbt**: Data modeling & transformation
- **Apache Airflow**: Orchestration & scheduling
- **SQL**, **Python**

## 🧩 Project Overview
This project simulates a real-world e-commerce business case by building a data pipeline to:
- Ingest and store raw order data (~10K records)
- Transform into fact/dim tables using dbt
- Schedule ELT jobs and send alerts on delayed orders via Airflow
- Enable downstream analytics

## 📊 Features
- Medallion architecture (Bronze → Silver → Gold layers)
- Delayed order detection & alerting
- Dimensional modeling with dbt
- Workflow orchestration using Airflow DAGs

## 🏗️ Architecture
📌 *(Add a pipeline diagram here if available)*

## ⚙️ Getting Started (Optional)
```bash
git clone https://github.com/yourusername/ecommerce-data-pipeline.git
cd ecommerce-data-pipeline
# Set up Snowflake, Airflow, dbt configs as needed
```

## ✍️ Author
**Subha Chandra Mondal**  
[LinkedIn](https://linkedin.com/in/subha-chandra-mondal-669731249) | [GitHub](https://github.com/Subh716)
